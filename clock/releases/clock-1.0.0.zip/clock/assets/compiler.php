<?php


$base =  get_site_url();

$options = array(
	'baseUrl' => $base . CLOCK_PATH
);

$options = json_encode($options);
echo "
<script>
var WP = {CONFIG: $options};
</script>
";
?>