<?php
/*
Plugin Name: Clock Module
Plugin URI: http://satinjeet.github.io/clock
Description: A simple Retro styled analog Clock to show on every Page.
Version: 1.0.0
Author: Satin Jeet, satin.jeet@gmail.com
Author URI: http://iota-coder.me/
License: GPL2
*/

/*  Copyright 2011  Satin Jeet  (email : satin.jeet@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
?>

<?php

// some definition we will use
define( 'CLOCK_PUGIN_NAME', 'Clock Module');
define( 'CLOCK_PLUGIN_DIRECTORY', 'clock');
define( 'CLOCK_CURRENT_VERSION', '1.0.0' );
define( 'CLOCK_CURRENT_BUILD', '1' );
define( 'CLOCK_LOGPATH', str_replace('\\', '/', WP_CONTENT_DIR).'/plugins/clock/logs/');
define( 'CLOCK_DIR', str_replace('\\', '/', WP_CONTENT_DIR).'/plugins/clock/');
define( 'CLOCK_PATH', '/wp-content/plugins/clock/');
define( 'CLOCK_DEBUG', false);
// i18n plugin domain for language files
define( 'EMU2_I18N_DOMAIN', 'clock' );

// load language files
function clock_set_lang_file() {
	# set the language file
	$currentLocale = get_locale();
	if(!empty($currentLocale)) {
		$moFile = dirname(__FILE__) . "/lang/" . $currentLocale . ".mo";
		if (@file_exists($moFile) && is_readable($moFile)) {
			load_textdomain(EMU2_I18N_DOMAIN, $moFile);
		}

	}
}

clock_set_lang_file();

// create custom plugin settings menu
// add_action( 'admin_menu', 'clock_create_menu' );

//call register settings function
// add_action( 'admin_init', 'clock_register_settings' );


register_activation_hook(__FILE__, 'clock_activate');
register_deactivation_hook(__FILE__, 'clock_deactivate');
register_uninstall_hook(__FILE__, 'clock_uninstall');

// activating the default values
function clock_activate() {
	add_option('clock_option_3', 'any_value');
}

// deactivating
function clock_deactivate() {
	// needed for proper deletion of every option
	delete_option('clock_option_3');
}

// uninstalling
function clock_uninstall() {
	# delete all data stored
	delete_option('clock_option_3');
	// delete log files and folder only if needed
	if (function_exists('clock_deleteLogFolder')) clock_deleteLogFolder();
}


function clock_register_settings() {
	//register settings
	register_setting( 'clock-settings-group', 'new_option_name' );
	register_setting( 'clock-settings-group', 'some_other_option' );
	register_setting( 'clock-settings-group', 'option_etc' );
}

// check if debug is activated
function clock_debug() {
	# only run debug on localhost
	if ($_SERVER["HTTP_HOST"]=="localhost" && defined('EPS_DEBUG') && EPS_DEBUG==true) return true;
}


function clock_enqueue_styles() {
	wp_enqueue_style( 'clock', CLOCK_PATH . 'js/clock.css', false );
}

function clock_enqueue_script() {
	require_once(CLOCK_DIR . 'assets/compiler.php');

	wp_enqueue_script( 'clock_config', CLOCK_PATH . 'js/config.js', false );
	wp_enqueue_script( 'clock', CLOCK_PATH . 'js/clock.js', false );
}

add_action( 'wp_enqueue_scripts', 'clock_enqueue_styles' );
add_action( 'wp_enqueue_scripts', 'clock_enqueue_script' );
?>
